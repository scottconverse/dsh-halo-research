# Qwen Next on Strix Halo and Blackwell

Open Qwen-Next-Halo-Blackwell-Report.html in a browser. It is a standalone, offline report: figures, measurements and exact primary result JSON are embedded. Nothing starts a model server. No external fonts, scripts, analytics or network resources are required.

Contents:
- 8 figures, each supplied as SVG and 300 dpi PNG.
- 72 request rows from 13 configurations; 61 coding answers plus 11 warmups.
- 10 native MTP comparisons, 15 no-drafting engine comparisons and 16 measured calibration rows.
- Exact model/shard identities, methods, settings, response-length controls, exclusions and limitations.
- evidence/: 29 byte-preserved primary result/calibration JSON files.
- requests.csv, native-mtp-comparisons.csv, engine-comparisons.csv, calibration.csv and dataset.json.
- source-register.json: original input identities and SHA-256 hashes. Some private original logs are represented by hashes/selected fields rather than copied in full.
- data-verification.json and headless-verification.json: numerical checks and headless browser results.
- build_publication.py, analysis_data.py, figures.py, templates, CSS, JS and pinned build requirements.

Build processing uses Python, NumPy, matplotlib and Jinja2. Rebuilding requires the original parent evidence tree at D:/DSH-Benchmarks/llama-v1-20261117 (or equivalent relative layout). The package does not contain all original logs and benchmark harness inputs, model weights or runtime binaries. Viewing the HTML, examining raw results and importing the data requires no original evidence tree. The headless browser verification script uses installed Microsoft Edge through Playwright; it opens no visible window.

All measurements are the preserved 17 November 2026 experiment record. No new inference was performed to create this report. Historical unloading/preservation receipts describe that experiment cutoff, not current machine state at a later reading date. No claim of peer review or statistical generality is made.

The SHA256SUMS.txt file covers this package's report, data, figures and source files. Verify individual files in PowerShell with Get-FileHash -Algorithm SHA256 <filename>.
