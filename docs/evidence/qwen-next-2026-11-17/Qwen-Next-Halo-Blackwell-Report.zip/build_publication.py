# Offline publication generator; existing benchmark evidence is read-only.
from analysis_data import *
from figures import figures
from jinja2 import Environment, FileSystemLoader, select_autoescape
from markupsafe import Markup, escape
import base64,platform,importlib.metadata

def fmt(v,n=2):return '—' if v is None else f'{v:,.{n}f}'
def ref(sid):return Markup(f'<a href="#{escape(sid)}" aria-label="Evidence {escape(sid)}">[{escape(sid)}]</a>')
def fig(n):
 f=next(x for x in figures if x['number']==n)
 svg=f['svg'].replace('<svg ',f'<svg role="img" aria-label="{escape(f["title"])}" ',1)
 return Markup(f'<figure id="figure-{n}">{svg}<figcaption><strong>Figure {n}. {escape(f["title"])}.</strong> {escape(f["caption"])}</figcaption><div class="figure-links hide-print"><button onclick="downloadFigure({n},\'svg\')">Download SVG</button><button onclick="downloadFigure({n},\'png\')">Download 300 dpi PNG</button></div></figure>')
D['raw_files']={s['id']:{'filename':s['published_file'],'base64':base64.b64encode((E/s['published_file']).read_bytes()).decode(),'sha256':s['original_sha256']} for s in sources if s['published_file']}
D['figure_files']={str(f['number']):{ext:{'filename':f['slug']+'.'+ext,'base64':base64.b64encode((F/(f['slug']+'.'+ext)).read_bytes()).decode()} for ext in ('svg','png')} for f in figures}
D['figure_captions']=[{k:v for k,v in f.items() if k!='svg'} for f in figures]
# Compact payload keeps full numeric precision. Exact source bytes are separately encoded.
payload=json.dumps(D,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
env=Environment(loader=FileSystemLoader(str(O)),autoescape=select_autoescape(default=True))
env.globals.update(fmt=fmt,ref=ref,fig=fig,tojson=lambda x:json.dumps(x,indent=2,ensure_ascii=False))
context={k:v for k,v in globals().copy().items() if not k.startswith('_')}
context.update(css=(O/'style.css').read_text(encoding='utf-8-sig'),javascript=(O/'report.js').read_text(encoding='utf-8-sig'),payload=payload,total_model_bytes=sum(x['bytes'] for x in model_public),engine24=next(x for x in comparisons if x['host']=='5070 Ti' and x['workload']=='document-1200'))
html=env.get_template('report.html.j2').render(**context)
(O/'Qwen-Next-Halo-Blackwell-Report.html').write_text(html,encoding='utf-8')
versions={'python':platform.python_version(),**{x:importlib.metadata.version(x) for x in ['matplotlib','numpy','Jinja2','pillow']}}
(O/'build-environment.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
(O/'requirements.txt').write_text('\n'.join(f'{x}=={versions[x]}' for x in ['matplotlib','numpy','Jinja2','pillow'])+'\n',encoding='utf-8')
checks={'requests':len(rows),'warmups':sum(x['workload']=='warmup' for x in rows),'coding_answers':len(coding),'cases':len(cases),'native_mtp_pairs':len(paired),'engine_pairs':len(comparisons),'calibration_rows':len(cal),'figures':len(figures),'source_count':len(sources),'byte_identical_published_sources':all(sha(E/s['published_file'])==s['original_sha256'] for s in sources if s['published_file']),'all_61_validation_receipts_matched':True,'rpc_answer_sha_matches_both_single_gpus':True}
assert checks['byte_identical_published_sources']
(O/'data-verification.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks));print('HTML bytes:',len(html.encode('utf-8')))
