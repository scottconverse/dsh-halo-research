from pathlib import Path
import json,hashlib,csv,re
R=Path(__file__).resolve().parent.parent;O=R/'publication';F=O/'figures';E=O/'evidence'
for d in (O,F,E):d.mkdir(exist_ok=True)
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
labels=['code-0','code-1','code-2','document-300','document-1200']
pretty={'code-0':'Code trial 1','code-1':'Code trial 2','code-2':'Code trial 3','document-300':'6,123-token prompt','document-1200':'24,842-token prompt','warmup':'Warmup'}
specs=[('H-GPU','Halo','llama.cpp','off','GPU-offload baseline; lazy PLE','halo-rocm-baseline',None,None,4096,4096,'Complete'),('H-S0','Halo','Strata','off','44.63 GiB expert cache','halo-strata-budget18000-off',44.63,20,4096,None,'Complete'),('H-SM','Halo','Strata','on','44.63 GiB expert cache','halo-strata-budget18000-mtp',44.63,20,4096,None,'Complete'),('H-C0','Halo','llama.cpp','off','32 GiB expert cache','halo-rocm-cache32768-off',32,20,4096,512,'Complete selected five-case suite'),('H-CM','Halo','llama.cpp','on','32 GiB expert cache; NVMe head','halo-rocm-cache32768-mtp-nvme',32,20,4096,512,'Complete selected five-case suite'),('B70-N','5070 Ti','llama.cpp','off','6 GiB expert cache','blackwell-5070-llama-off-ws8to18-matched-grace',6,18,4096,4096,'Complete'),('B70-S0','5070 Ti','Strata','off','8.96 GiB automatic cache','blackwell-5070-strata-off',8.96,12,4096,None,'Complete'),('B70-SM','5070 Ti','Strata','on','7.94 GiB automatic cache','blackwell-5070-strata-mtp',7.94,12,4096,None,'Complete'),('B60-N','5060 Ti','llama.cpp','off','6 GiB expert cache','blackwell-5060-llama-off-ws8to18-matched-grace',6,18,4096,4096,'Complete'),('B60-NM','5060 Ti','llama.cpp','on','6 GiB expert cache; native MTP','blackwell-5060-llama-mtp-ws8to18-matched-grace',6,18,4096,4096,'Complete'),('B60-S0','5060 Ti','Strata','off','9.12 GiB automatic cache','blackwell-5060-strata-off',9.12,12,4096,None,'Complete'),('B60-SM','5060 Ti','Strata','on','8.08 GiB automatic cache','blackwell-5060-strata-mtp',8.08,12,4096,None,'Complete'),('RPC-0','Two GPUs','llama.cpp RPC','off','18 GiB requested combined cache; CPU share 0','blackwell-rpc-cache18432-off-grace',18,18,4096,4096,'Warmup + one code answer; deliberately stopped')]
cases={};rows=[];sources=[];originals={}
def register(p,description,representation='receipt'):
 p=Path(p);sid='E'+str(len(sources)+1).zfill(3);dest=None
 if representation=='raw-result':
  dest=E/(sid+'-'+p.name);dest.write_bytes(p.read_bytes())
 sources.append({'id':sid,'file':p.name,'description':description,'original_sha256':sha(p),'representation':representation,'published_file':dest.name if dest else None});originals[sid]=p;return sid
for cid,host,engine,mtp,desc,stem,cache,ws,batch,ub,status in specs:
 p=R/(stem+'-results.json');j=load(p);sid=register(p,f'{cid}: {host}, {engine}, MTP {mtp}','raw-result')
 c={'id':cid,'model_id':'M1','host':host,'engine':engine,'mtp':mtp,'description':desc,'stem':stem,'cache_gib':cache,'working_set_cap_gib':ws,'batch':batch,'ubatch':ub,'status':status,'source':sid,'load_s':j['load_s'],'startup_min_free_ram_gib':j.get('startup_min_free_host_gib'),'requests':{}}
 for q in j['results']:
  z=q['response'];t=z['engine_timings'][-1];x={'model_id':'M1','case_id':cid,'host':host,'engine':engine,'mtp':mtp,'workload':q['label'],'prompt_tokens':t['prompt_n'],'output_tokens':t['predicted_n'],'prefill_tps':t['prompt_per_second'],'decode_tps':t['predicted_per_second'],'prefill_s':t['prompt_ms']/1000,'decode_s':t['predicted_ms']/1000,'wall_s':q['wall_s'],'ttft_s':z.get('ttft_s'),'cached_prompt_tokens':t.get('cache_n'),'draft_proposed':t.get('draft_n'),'draft_accepted':t.get('draft_n_accepted'),'answer_sha256':hashlib.sha256(z['answer'].encode()).hexdigest(),'source':sid};c['requests'][q['label']]=x;rows.append(x)
 cases[cid]=c
assert len(rows)==72
v=load(R/'saved-code-validation.json');vd={(x['file'],x['label'],x['answer_sha256']):x for x in v};coding=[x for x in rows if x['workload']!='warmup']
for x in coding:
 a=vd[(cases[x['case_id']]['stem']+'-results.json',x['workload'],x['answer_sha256'])];assert a['passed'] and a['independent_cases']==10
assert len(coding)==61 and len(v)==90
validation_id=register(R/'saved-code-validation.json','90 archived validation receipts; 61 selected coding answers match')
comparisons=[];paired=[]
for host,ni,si in [('Halo','H-GPU','H-S0'),('5070 Ti','B70-N','B70-S0'),('5060 Ti','B60-N','B60-S0')]:
 for label in labels:
  a=cases[ni]['requests'][label];b=cases[si]['requests'][label];comparisons.append({'host':host,'workload':label,'baseline_case':ni,'comparison_case':si,'baseline_tps':a['decode_tps'],'comparison_tps':b['decode_tps'],'ratio':b['decode_tps']/a['decode_tps'],'native_below_pct':100*(1-a['decode_tps']/b['decode_tps']),'strata_above_pct':100*(b['decode_tps']/a['decode_tps']-1)})
for host,ai,bi in [('Halo / 32 GiB cache','H-C0','H-CM'),('5060 Ti / 6 GiB cache','B60-N','B60-NM')]:
 for label in labels:
  a=cases[ai]['requests'][label];b=cases[bi]['requests'][label];paired.append({'host':host,'workload':label,'off_case':ai,'on_case':bi,'off_tps':a['decode_tps'],'on_tps':b['decode_tps'],'throughput_change_pct':100*(b['decode_tps']/a['decode_tps']-1),'token_time_change_pct':100*(a['decode_tps']/b['decode_tps']-1),'wall_change_pct':100*(b['wall_s']/a['wall_s']-1),'off_output_tokens':a['output_tokens'],'on_output_tokens':b['output_tokens'],'same_answer':a['answer_sha256']==b['answer_sha256'],'accepted':b['draft_accepted'],'proposed':b['draft_proposed']})
rpc=cases['RPC-0']['requests']['code-0'];assert len({cases[k]['requests']['code-0']['answer_sha256'] for k in ['RPC-0','B70-N','B60-N']})==1
rpc_factor=cases['B70-N']['requests']['code-0']['decode_tps']/rpc['decode_tps']
model_public=[{'file':x['Name'],'bytes':x['Length'],'sha256':x['DownloadReceipt'].split()[-1],'last_write_utc':x['LastWriteTimeUtc']} for x in load(R/'original-model-manifest.json')]
model_id=register(R/'original-model-manifest.json','Original base-file identity and hash receipts')
head=load(R/'native-mtp-verified.json');head_id=register(R/'native-mtp-verified.json','Native MTP layout, quantization and final hash')
config=load(R/'conversion-source-receipt.json');config_id=register(R/'conversion-source-receipt.json','Pinned conversion source and model-config snapshot')
meta_id=register(R/'halo-rocm-baseline.log','Observed GGUF metadata, compiler and Halo CPU/GPU','selected fields')
def folder(c):
 return R/('evidence-5060' if c['id'].startswith('B60') else 'evidence-5070' if c['id'].startswith('B70') else 'evidence-rpc-cache0' if c['id'].startswith('RPC') else '')
def neutral(x):return '{BENCH_ROOT}/'+Path(x).name if isinstance(x,str) and re.match(r'^[A-Za-z]:[\\/]',x) else x
commands={}
for cid,c in cases.items():
 p=folder(c)/(c['stem']+'-command.json')
 if not p.exists():p=R/(c['stem']+'-command.json')
 if p.exists():
  commands[cid]={'argv':[neutral(x) for x in load(p)],'source':register(p,f'{cid}: executed arguments, path-neutral view','sanitized command')}
  if c['engine']=='Strata':
   cp=folder(c)/(c['stem']+'-config.json')
   if not cp.exists():cp=R/(c['stem']+'-config.json')
   commands[cid]['strata_engine_args']=[neutral(x) for x in load(cp)['args']]
cal=[]
for host,d in [('Halo',R/'halo-moe-mmap-tune'),('5060 Ti',R/'evidence-5060/blackwell-moe-mmap-tune-ws18'),('5070 Ti',R/'evidence-5070/blackwell-moe-mmap-tune-ws18-grace')]:
 for p in sorted(d.glob('run-*.json')):
  q=load(p);cal.append({'host':host,'cache_mib':q['mib'],'cpu_share':q['share'],'tps':q['tokens']/(q['ms']/1000),'tokens':q['tokens'],'duration_s':q['ms']/1000,'hit_fraction':q['hits']/(q['hits']+q['misses']),'expert_upload_mib':q['up_mib'],'source':register(p,f'{host}: measured calibration row','raw-result')})
assert len(cal)==16
network=load(R/'rpc-halo-network-delta.json');net_id=register(R/'rpc-halo-network-delta.json','Whole-Halo adapter network observations')
tele=load(R/'workload-telemetry-summary.json');tele_id=register(R/'workload-telemetry-summary.json','Whole-job disk, fault and sampled GPU summaries')
series={}
for cid in ['B70-N','B70-SM','RPC-0']:
 c=cases[cid];p=folder(c)/(c['stem']+'-memory.jsonl');a=[]
 for line in p.read_text(encoding='utf-8').splitlines():
  q=json.loads(line)
  if 'elapsed_s' not in q or 'disk' not in q:continue
  z={'elapsed_s':q['elapsed_s'],'free_ram_gib':q['free_host_gib'],'free_commit_gib':q['commit_free_gib'],'system_disk_read_bytes':q['disk']['read_bytes'],'process_rss_bytes':q['process_memory']['rss'],'parent_cpu_percent':q.get('cpu_percent')}
  if 'nvidia_smi' in q:
   f=q['nvidia_smi']['csv'].split(',')
   if len(f)>=6:z.update(gpu_util_percent=float(f[3]),gpu_used_mib=float(f[1]),gpu_power_w=float(f[5]))
  a.append(z)
 series[cid]=a;register(p,f'{cid}: normalized time-series fields','selected fields')
final_ids=[register(p,desc) for p,desc in [(R/'halo-final-preservation.json','Final Halo preservation and owned-process readback'),(R/'evidence-5070/remote-final-preservation.json','Final 5070 cleanup and weight metadata'),(R/'evidence-5060/remote-final-preservation.json','Final 5060 cleanup and weight metadata')]]
mtp24=next(x for x in paired if x['host'].startswith('5060') and x['workload']=='document-1200');mtp6=next(x for x in paired if x['host'].startswith('5060') and x['workload']=='document-300')
for rel,desc in [('halo-storage.json','Halo storage inventory'),('native-mtp-nvme-copy.json','Native auxiliary NVMe copy identity'),('run_halo.py','Executed request and memory guard harness'),('run_blackwell.py','Blackwell orchestration and child environment'),('startup-guard-approved-checks.json','Approved loading exception boundary checks'),('evidence-rpc-cache0/blackwell-rpc-cache18432-off-grace.log','RPC cache sizes, backend and loading trace'),('evidence-rpc-cache0/rpc-live-gpu-allocation.json','RPC sampled local GPU allocation'),('evidence-rpc-cache0/worker-5060/rpc-live-gpu-allocation.json','RPC sampled remote GPU allocation')]:
 register(R/rel,desc,'selected fields')
D={'report_version':'2.0','record_date':'2026-11-17','model':{'id':'M1','name':'Qwen3.8-Flash-Next GSQ-RCO / IQ3_S','shards':model_public,'native_head':head},'cases':cases,'requests':rows,'native_mtp_comparisons':paired,'engine_comparisons':comparisons,'calibration':cal,'sources':sources,'commands':commands,'telemetry':series,'correctness':{'primary_coding_answers':61,'archive_receipts':90,'all_primary_receipts_matched':True,'task_count':1,'per_answer_test_cases':10}}
(O/'dataset.json').write_text(json.dumps(D,indent=2),encoding='utf-8')
for name,data in [('requests.csv',rows),('native-mtp-comparisons.csv',paired),('engine-comparisons.csv',comparisons),('calibration.csv',cal)]:
 with (O/name).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(O/'source-register.json').write_text(json.dumps(sources,indent=2),encoding='utf-8')
