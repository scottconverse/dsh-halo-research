from pathlib import Path
import json,csv,hashlib,math,re
from playwright.sync_api import sync_playwright
O=Path(__file__).resolve().parent;R=O.parent
html=O/'Qwen-Next-Halo-Blackwell-Report.html'
checks={};errors=[];requests=[]
# Independent pass: published CSV fields versus byte-preserved primary JSON.
rows=list(csv.DictReader((O/'requests.csv').open(encoding='utf-8')))
sources=json.loads((O/'source-register.json').read_text())
source_map={s['id']:s for s in sources}
for r in rows:
 raw=json.loads((O/'evidence'/source_map[r['source']]['published_file']).read_text(encoding='utf-8-sig'))
 q=next(q for q in raw['results'] if q['label']==r['workload']);t=q['response']['engine_timings'][-1]
 for col,key in [('prefill_tps','prompt_per_second'),('decode_tps','predicted_per_second'),('prompt_tokens','prompt_n'),('output_tokens','predicted_n')]:assert float(r[col])==float(t[key]),(r['case_id'],r['workload'],col)
 assert float(r['wall_s'])==q['wall_s']
 assert r['answer_sha256']==hashlib.sha256(q['response']['answer'].encode()).hexdigest()
checks['all_72_csv_rows_match_raw_timings_counts_wall_and_answer_hash']=True
for fn in ['native-mtp-comparisons.csv','engine-comparisons.csv']:
 for a in csv.DictReader((O/fn).open(encoding='utf-8')):
  if 'off_tps' in a:
   expected=100*(float(a['on_tps'])/float(a['off_tps'])-1);assert math.isclose(float(a['throughput_change_pct']),expected,abs_tol=1e-10)
  else:assert math.isclose(float(a['ratio']),float(a['comparison_tps'])/float(a['baseline_tps']),rel_tol=1e-12)
checks['all_comparison_ratios_recomputed_independently']=True
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,channel="msedge")
 page=browser.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http:','https:')) else None)
 page.goto(html.as_uri());page.wait_for_function("typeof dataset !== 'undefined'")
 assert page.locator('figure').count()==8
 assert page.locator('#request-table tbody tr').count()==72
 assert page.locator('svg[role=img]').count()==8
 checks['desktop_charts_tables_and_embedded_json_render']=True
 missing=page.evaluate("""() => [...document.querySelectorAll('a[href^="#"]')].map(a=>a.getAttribute('href').slice(1)).filter(id=>!document.getElementById(id))""")
 assert not missing,missing
 checks['all_internal_evidence_and_case_links_resolve']=True
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
 page.screenshot(path=str(O/'desktop-cover.png'),full_page=False)
 page.locator('#figure-2').screenshot(path=str(O/'desktop-native-mtp.png'))
 page.locator('#figure-7').screenshot(path=str(O/'desktop-rpc.png'))
 page.locator('#request-filter').fill('5060')
 assert page.locator('#request-table tbody tr:visible').count()==24
 page.locator('#request-filter').fill('')
 with page.expect_download() as di:page.get_by_role('button',name='Download request CSV',exact=True).click()
 di.value.save_as(str(O/'browser-download-requests.csv'))
 assert len(list(csv.DictReader((O/'browser-download-requests.csv').open(encoding='utf-8'))))==72
 with page.expect_download() as di:page.locator('#E001 button').click()
 di.value.save_as(str(O/'browser-download-source.json'))
 assert hashlib.sha256((O/'browser-download-source.json').read_bytes()).hexdigest()==source_map['E001']['original_sha256']
 embedded=page.evaluate('Object.entries(dataset.raw_files).map(([id,f])=>({id,b64:f.base64,sha:f.sha256}))')
 import base64
 for f in embedded:assert hashlib.sha256(base64.b64decode(f['b64'])).hexdigest()==f['sha']
 checks['filter_and_csv_download_work']=True;checks['all_29_embedded_raw_files_hash_match']=len(embedded)==29
 assert checks['all_29_embedded_raw_files_hash_match']
 with page.expect_download() as di:page.locator('#figure-2').get_by_role('button',name='Download SVG',exact=True).click()
 di.value.save_as(str(O/'browser-download-figure.svg'))
 assert b'<svg' in (O/'browser-download-figure.svg').read_bytes()
 checks['offline_vector_download_works']=True
 page.set_viewport_size({'width':390,'height':844})
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),page.evaluate('[document.documentElement.scrollWidth,innerWidth]')
 page.locator('header').scroll_into_view_if_needed();page.screenshot(path=str(O/'mobile-cover.png'))
 checks['mobile_390px_has_no_page_overflow']=True
 page.set_viewport_size({'width':1440,'height':1050});page.emulate_media(media='print')
 assert page.locator('nav').evaluate('(e)=>getComputedStyle(e).display')=='none'
 checks['print_styles_applied']=True
 page.emulate_media(media='screen')
 checks['javascript_errors']=errors;checks['external_resource_requests']=requests
 assert not errors and not requests
 browser.close()
(O/'headless-verification.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))


