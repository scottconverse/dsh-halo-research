import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from analysis_data import *
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':11,'axes.titlesize':13,'axes.titleweight':'bold','axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','savefig.facecolor':'white','axes.axisbelow':True})
colors={'native':'#285c91','strata':'#bd641e','green':'#317763','purple':'#7251a2','dark':'#122a42'}
figures=[]
def clean(ax):ax.grid(axis='x',color='#e4e8ec',lw=.7)
def save(fig,slug,title,caption):
 fig.savefig(F/(slug+'.svg'),bbox_inches='tight');fig.savefig(F/(slug+'.png'),dpi=300,bbox_inches='tight');plt.close(fig)
 svg=(F/(slug+'.svg')).read_text(encoding='utf-8');svg=svg[svg.index('<svg'):];svg=re.sub(r'width="[^"]+"\s+height="[^"]+"','',svg,count=1)
 figures.append({'number':len(figures)+1,'slug':slug,'title':title,'caption':caption,'svg':svg})
fig,axs=plt.subplots(2,3,figsize=(14,8),layout='constrained')
for col,(host,ids) in enumerate([('Halo',['H-GPU','H-S0','H-SM']),('5070 Ti',['B70-N','B70-S0','B70-SM']),('5060 Ti',['B60-N','B60-NM','B60-S0','B60-SM'])]):
 for row,(key,label,xmax) in enumerate([('prefill_tps','Prompt processing (tokens/s)',970),('decode_tps','Generation (tokens/s)',66)]):
  ax=axs[row,col];names=[('Native' if cases[k]['engine']=='llama.cpp' else 'Strata')+(' + MTP' if cases[k]['mtp']=='on' else ' / off') for k in ids];vals=[cases[k]['requests']['document-1200'][key] for k in ids]
  bars=ax.barh(names,vals,color=[colors['native'] if cases[k]['engine']=='llama.cpp' else colors['strata'] for k in ids],height=.57);ax.invert_yaxis();ax.set_xlim(0,xmax);ax.set_xlabel(label);ax.set_title(host if row==0 else '');clean(ax)
  for bar,val,k in zip(bars,vals,ids):
   if cases[k]['mtp']=='on':bar.set_hatch('//')
   ax.text(val+xmax*.015,bar.get_y()+bar.get_height()/2,f'{val:.2f}',va='center',fontsize=10)
fig.suptitle('24,842-token prompts: tested Strata deployments lead in prefill and decode',fontsize=16,weight='bold')
save(fig,'01-long-context','Long-context prefill and generation','Each bar is one completed request. Blue: native; orange: Strata; hatching: MTP. Axes start at zero and share scales by row. Expert-cache sizes differ across engines. This is an observed deployment comparison, not an equal-resource engine experiment; answer lengths appear in the data table.')
fig,axs=plt.subplots(1,2,figsize=(13.5,5.1),sharex=True,layout='constrained')
for ax,host in zip(axs,['Halo / 32 GiB cache','5060 Ti / 6 GiB cache']):
 q=[p for p in paired if p['host']==host];vals=[p['throughput_change_pct'] for p in q];ax.barh([pretty[p['workload']] for p in q],vals,color=colors['native'],height=.57);ax.axvline(0,color=colors['dark'],lw=1);ax.set_xlim(-62,5);ax.invert_yaxis();ax.set_title(host);ax.set_xlabel('Change in decode throughput with MTP (%)');clean(ax)
 for y,val in enumerate(vals):ax.text(val-1,y,f'{val:+.2f}%',ha='right',va='center',weight='bold',fontsize=10)
fig.suptitle('Native MTP reduced throughput in every completed paired workload',fontsize=16,weight='bold')
save(fig,'02-native-mtp','Native MTP percentage changes','Baseline: drafting off on the same host, target cache, working-set limit and target microbatch. One execution per workload; no confidence intervals or significance claim. Percentages compare reported throughput without assuming equal answer lengths. The 6K 5060 answers were byte-identical.')
fig,ax=plt.subplots(figsize=(11,4.4),layout='constrained');arr=np.array([[next(q['ratio'] for q in comparisons if q['host']==h and q['workload']==l) for l in labels] for h in ['Halo','5070 Ti','5060 Ti']]);im=ax.imshow(arr,cmap='Blues',vmin=1,vmax=5,aspect='auto');ax.set_xticks(range(5),['Code 1','Code 2','Code 3','6K prompt','24K prompt']);ax.set_yticks(range(3),['Halo','5070 Ti','5060 Ti']);ax.set_title('Drafting off: Strata/native decode-throughput ratios',pad=16)
for (y,x),value in np.ndenumerate(arr):ax.text(x,y,f'{value:.2f}×',ha='center',va='center',color='white' if value>3 else colors['dark'],weight='bold',fontsize=14)
fig.colorbar(im,ax=ax,label='Strata tokens/s ÷ native tokens/s',shrink=.8)
save(fig,'03-engine-ratios','No-drafting engine ratios','A ratio of 2 means twice the observed throughput, not a 200% reduction in latency. Both sides disable drafting; expert-cache sizes, representations and scheduling differ. No averaged composite score is calculated across unlike workloads.')
ids=['H-GPU','H-S0','H-SM','B70-N','B70-S0','B70-SM','B60-N','B60-NM','B60-S0','B60-SM'];fig,ax=plt.subplots(figsize=(13,7),layout='constrained');ys=np.arange(len(ids));pp=[cases[k]['requests']['document-1200']['prefill_s'] for k in ids];dd=[cases[k]['requests']['document-1200']['decode_s'] for k in ids]
ax.barh(ys,pp,label='Engine prompt time',color=colors['native']);ax.barh(ys,dd,left=pp,label='Engine generation time',color=colors['strata'],hatch='//');ax.set_yticks(ys,[k+' · '+cases[k]['host'] for k in ids]);ax.invert_yaxis();ax.set_xlim(0,560);ax.set_xlabel('Seconds');ax.set_title('24K interaction time is mostly prompt processing in these requests');clean(ax)
for y,k,p,d in zip(ys,ids,pp,dd):
 q=cases[k]['requests']['document-1200'];ax.text(p+d+5,y,f'{q["wall_s"]:.1f}s wall · {q["output_tokens"]} output tokens',va='center',fontsize=9)
ax.legend(loc='lower right')
save(fig,'04-latency','Long-context time components','Bars show engine prompt and generation intervals; labels show independently recorded client wall time. Small timing-boundary residuals are not silently added to either component. Output counts are explicit because total latency is not a fixed-output comparison.')
fig,axs=plt.subplots(1,3,figsize=(14,4.9),sharey=True,layout='constrained')
for ax,host,ids in zip(axs,['Halo','5070 Ti','5060 Ti'],[['H-GPU','H-S0','H-SM'],['B70-N','B70-S0','B70-SM'],['B60-N','B60-NM','B60-S0','B60-SM']]):
 for k in ids:
  c=cases[k];ax.plot([1,2,3],[c['requests']['code-'+str(i)]['decode_tps'] for i in range(3)],color=colors['native'] if c['engine']=='llama.cpp' else colors['strata'],ls='--' if c['mtp']=='on' else '-',marker='s' if c['mtp']=='on' else 'o',lw=2,label=('Native' if c['engine']=='llama.cpp' else 'Strata')+(' + MTP' if c['mtp']=='on' else ' / off'))
 ax.set_title(host);ax.set_xticks([1,2,3]);ax.set_xlabel('Serial code-trial position');ax.set_ylim(0,70);ax.grid(color='#e4e8ec');ax.legend(fontsize=9,loc='upper left')
axs[0].set_ylabel('Generation tokens/s');fig.suptitle('Later short-code trials usually accelerated; order and cache history matter',fontsize=15,weight='bold')
save(fig,'05-serial-trials','Serial short-code progression','Each prompt includes a distinct trial marker. These are not independent cold starts or identical-prompt replications, so dispersion is not used to invent a confidence interval. Prompt reuse was disabled; expert-cache and OS cache state were not reset.')
fig,axs=plt.subplots(1,3,figsize=(14,4.6),sharey=True,layout='constrained')
for ax,host in zip(axs,['Halo','5060 Ti','5070 Ti']):
 vals=[x for x in cal if x['host']==host]
 for idx,size in enumerate(sorted({x['cache_mib'] for x in vals})):
  q=sorted([x for x in vals if x['cache_mib']==size],key=lambda x:x['cpu_share']);ax.plot([x['cpu_share'] for x in q],[x['tps'] for x in q],marker='o' if idx==0 else 's',ls='-' if idx==0 else '--',color=colors['native'] if idx==0 else colors['strata'],lw=2,label=f'{size:,} MiB')
  for x in q:ax.annotate(f'{x["tps"]:.1f}',(x['cpu_share'],x['tps']),xytext=(0,7 if idx==0 else -16),textcoords='offset points',ha='center',fontsize=9)
 ax.set_title(host);ax.set_xlabel('Requested share of misses on CPU');ax.set_xticks([0,.5,.95]);ax.set_xlim(-.04,1.02);ax.set_ylim(0,20);ax.grid(color='#e4e8ec');ax.legend(fontsize=9)
axs[0].set_ylabel('Measured prose-generation tokens/s');fig.suptitle('CPU-share effects are machine-specific; the 5070 Ti sweep is incomplete',fontsize=15,weight='bold')
save(fig,'06-calibration','Measured cache and CPU-share sweep','Official calibration code, shortened two-request protocol: first row 2×512 tokens, later rows 2×256. Curves connect measured rows only. The 5060 internal fit passed; the Halo fit was rejected; 5070 was incomplete. Predictions are never plotted as measurements.')
fig,axs=plt.subplots(1,2,figsize=(13,5.2),layout='constrained');ax=axs[0];model=np.array([1822.94,2160.06])/1024;cache=np.array([9209.25,9205.10])/1024;used=np.array([13704,13677])/1024;total=np.array([16303,16311])/1024;other=used-model-cache
for vals,bottom,label,color,hatch in [(model,0,'Model buffers',colors['native'],''),(cache,model,'Expert-cache banks',colors['green'],'//'),(other,model+cache,'Other observed VRAM',colors['strata'],'..'),(total-used,used,'Free VRAM','#e2e7ec','')]:ax.bar(['5070 Ti','5060 Ti'],vals,bottom=bottom,label=label,color=color,hatch=hatch,edgecolor='white',width=.55)
ax.set_ylabel('GiB');ax.set_ylim(0,17.3);ax.set_title('Both GPUs held substantial allocations');ax.legend(fontsize=9,loc='upper center',bbox_to_anchor=(.5,-.09),ncols=2);ax.grid(axis='y',color='#e4e8ec');ax=axs[1];vv=[cases[k]['requests']['code-0']['decode_tps'] for k in ['B70-N','B60-N','RPC-0']];bars=ax.barh(['5070 Ti alone','5060 Ti alone','Two-GPU RPC'],vv,color=[colors['native'],colors['native'],colors['purple']],height=.56);ax.invert_yaxis();ax.set_xlim(0,6.7);ax.set_xlabel('Generation tokens/s');ax.set_title('Identical coding answer: RPC was much slower');clean(ax)
for b,value in zip(bars,vv):ax.text(value+.1,b.get_y()+b.get_height()/2,f'{value:.3f}',va='center',weight='bold')
save(fig,'07-rpc','Distributed capacity and speed','Left: model/cache allocation and sampled total VRAM. Other VRAM includes runtime, KV, compute and desktop usage; allocated banks do not prove every slot was useful. Right: 63 prompt tokens, 169 output tokens and byte-identical answer text in all three cases. Cache budgets and topology differ; one observed request per condition.')
fig,axs=plt.subplots(3,1,figsize=(13,8),sharex=True,layout='constrained')
for k,color,style in [('B70-N',colors['native'],'-'),('B70-SM',colors['strata'],'--')]:
 a=series[k];t=[x['elapsed_s'] for x in a];axs[0].plot(t,[x['free_ram_gib'] for x in a],label=k,color=color,ls=style,lw=1.5);g=[x for x in a if 'gpu_util_percent' in x];axs[1].scatter([x['elapsed_s'] for x in g],[x['gpu_util_percent'] for x in g],color=color,marker='o' if k=='B70-N' else 'x',s=18);b=a[0]['system_disk_read_bytes'];axs[2].plot(t,[(x['system_disk_read_bytes']-b)/2**30 for x in a],color=color,ls=style,lw=1.5)
axs[0].axhline(5,color='#9d3037',ls=':',lw=1,label='Inference RAM floor');axs[0].set_ylabel('Available RAM (GiB)');axs[1].set_ylabel('Sampled GPU busy (%)');axs[1].set_ylim(-2,102);axs[2].set_ylabel('System disk reads (GiB)');axs[2].set_xlabel('Seconds from each job’s own start');axs[0].legend(ncols=3,fontsize=9);axs[0].set_title('5070 Ti: substantial storage activity and intermittent GPU work')
for ax in axs:ax.grid(color='#e4e8ec',lw=.7)
save(fig,'08-telemetry','Whole-job telemetry on the 5070 Ti','B70-N: native off. B70-SM: Strata MTP. Curves include loading and all requests; job lengths differ. Disk counters include background traffic. GPU observations are sparse samples, not continuous or peak utilization. No isolated SSD bandwidth, energy-efficiency or causal bottleneck score is inferred.')
